"""Run on your PC with:  python -m unittest test_gcode_parser.py"""
import unittest
from gcode_parser import parse_line


class TestParseLine(unittest.TestCase):
    def test_g1_both(self):
        self.assertEqual(parse_line("G1 S47.847 E57.273"),
                         ("G1", {"S": 47.847, "E": 57.273}))

    def test_g1_only_shoulder(self):
        self.assertEqual(parse_line("G1 S90"), ("G1", {"S": 90.0}))

    def test_g1_no_params(self):
        self.assertEqual(parse_line("G1"), ("G1", {}))

    def test_m_commands(self):
        self.assertEqual(parse_line("M3"), ("M3", {}))
        self.assertEqual(parse_line("M5\n"), ("M5", {}))
        self.assertEqual(parse_line("  M18  "), ("M18", {}))

    def test_blank_and_comment(self):
        self.assertIsNone(parse_line(""))
        self.assertIsNone(parse_line("   \n"))
        self.assertIsNone(parse_line("; just a comment"))

    def test_inline_comment(self):
        self.assertEqual(parse_line("M3 ; pen down"), ("M3", {}))

    def test_bad_number(self):
        with self.assertRaises(ValueError):
            parse_line("G1 Sabc")


if __name__ == "__main__":
    unittest.main()
