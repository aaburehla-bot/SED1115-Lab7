"""Lab 7 - Plotter Control (SED 1115)

Flow: G-Code file -> parser -> command interpreter -> translate() -> PWM -> servos
"""
try:
    from machine import Pin, PWM  # type: ignore[import-not-found]
except ImportError:
    class Pin:
        def __init__(self, pin_id):
            self.pin_id = pin_id

    class PWM:
        def __init__(self, pin):
            self.pin = pin

        def freq(self, _):
            pass

        def duty_u16(self, _):
            pass

from time import sleep

from servo_translator import translate
from gcode_parser import parse_line

# ---------------------------------------------------------------- settings
GCODE_FILE = "line.gcode"      # change to the shape you want to draw

# Expansion board: J1 -> GPIO0, J2 -> GPIO1, J3 -> GPIO2
# (assumed: J1 = shoulder, J2 = elbow, J3 = wrist -- swap if yours differ)
SHOULDER_PIN = 0
ELBOW_PIN = 1
WRIST_PIN = 2

# Small calibration offsets (degrees) added to the angles. Tune these.
SHOULDER_OFFSET = 0
ELBOW_OFFSET = 0
WRIST_OFFSET = 0

PEN_UP_ANGLE = 0
PEN_DOWN_ANGLE = 30            # lab says ~30; do not go much beyond this

MOVE_DELAY = 0.05              # seconds to let servos settle after a G1
PEN_DELAY = 0.3                # seconds to let the pen lift/lower

# ------------------------------------------------------------------ servos
shoulder = PWM(Pin(SHOULDER_PIN))
elbow = PWM(Pin(ELBOW_PIN))
wrist = PWM(Pin(WRIST_PIN))
for _servo in (shoulder, elbow, wrist):
    _servo.freq(50)


def set_angle(servo, angle, offset=0):
    """Move a servo to an angle (degrees) using the safe translate()."""
    servo.duty_u16(translate(angle + offset))


def disable_servos():
    """M18: stop sending PWM to all servos."""
    for servo in (shoulder, elbow, wrist):
        servo.duty_u16(0)


# ------------------------------------------------------- command interpreter
def interpret(command, params):
    """Execute one parsed G-Code command."""
    if command == "G1":
        if "S" in params:
            set_angle(shoulder, params["S"], SHOULDER_OFFSET)
        if "E" in params:
            set_angle(elbow, params["E"], ELBOW_OFFSET)
        sleep(MOVE_DELAY)
    elif command == "M3":      # pen down
        set_angle(wrist, PEN_DOWN_ANGLE, WRIST_OFFSET)
        sleep(PEN_DELAY)
    elif command == "M5":      # pen up
        set_angle(wrist, PEN_UP_ANGLE, WRIST_OFFSET)
        sleep(PEN_DELAY)
    elif command == "M18":     # disable servos
        disable_servos()
    else:
        print("Unknown command ignored:", command)


# -------------------------------------------------------------- file reader
def run_gcode_file(filename):
    """Read a G-Code file line by line and execute each command."""
    with open(filename, "r") as f:
        for line_number, line in enumerate(f, 1):
            try:
                parsed = parse_line(line)
            except ValueError:
                print("Line", line_number, "skipped (bad number):", line.strip())
                continue
            if parsed is None:
                continue
            command, params = parsed
            interpret(command, params)


def main():
    set_angle(wrist, PEN_UP_ANGLE, WRIST_OFFSET)   # start with pen up
    sleep(PEN_DELAY)
    try:
        run_gcode_file(GCODE_FILE)
    finally:
        disable_servos()       # never leave servos stalling if something fails


main()
