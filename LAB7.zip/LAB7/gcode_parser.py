"""G-Code parser: turns one line of text into (command, params).

Pure Python (no `machine` import) so it can be unit tested on a PC.
"""


def parse_line(line):
    """Parse one line of G-Code.

    Returns None for blank/comment-only lines, otherwise a tuple
    (command, params) where command is a string like "G1" or "M3" and
    params is a dict such as {"S": 47.847, "E": 57.273}.

    Raises ValueError if a parameter value is not a number.
    """
    line = line.split(";")[0].strip()  # drop comments and whitespace
    if not line:
        return None

    words = line.split()
    command = words[0].upper()
    params = {}
    for word in words[1:]:
        params[word[0].upper()] = float(word[1:])  # e.g. "S90" -> {"S": 90.0}
    return command, params
